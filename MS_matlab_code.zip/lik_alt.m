%% The log likelihood under the alternative hypothesis, 2pi omitted
%%
function [est, loglik] = lik_alt(y,x,nd,lp,up,lq,uq,trm)
%nd: the number of parameters allowed to switch, including the intercept
    
    k = size(x,2);  % number of regressors
    
    if nd == 1      %only intercept switches
        in1 = unifrnd(-4,4);
        in2 = unifrnd(-4,4);
    else            %some slope coefficients also switch
        in1 = unifrnd(-1,1,nd,1)/k;
        in2 = unifrnd(-1,1,nd,1)/k;
        in1(1) = unifrnd(-4,4);
        in2(1) = unifrnd(-4,4);
    end
    
    if k == nd
       start_point = [in1;in2;unifrnd(0.1,4);...
                     unifrnd(lp,up);unifrnd(lp,up)]; 
       %1st regime coefs, 2nd regime coefs, variance, p, q
    else
       start_point = [in1;in2;unifrnd(-1,1,k-nd,1)/k;...
                      unifrnd(0.1,4);unifrnd(lp,up);unifrnd(lp,up)]; 
       %1st regime coefs, 2nd regime coefs, non-switching coefs, variance, p, q 
    end
    
    dims = size(start_point,1);
    model = @lik_model;
    
    lb = [-Inf*ones(dims-2, 1); lp; lq];
    ub = [Inf*ones(dims-2, 1); up; uq];
    
    %AA = [zeros(1,dims-2) -1 -1; zeros(1,dims-2) -1 1];
    %BB = [-(1+trm);0];
    
    AA = [zeros(1,dims-2) -1 -1];
    BB = -(1+trm);
    
    options  =  optimset('fmincon');
    options  =  optimset(options , 'Algorithm ','interior-point');
    options  =  optimset(options, 'Hessian','bfgs');
    options  =  optimset(options , 'TolFun'      , 1e-006);
    options  =  optimset(options , 'TolX'        , 1e-006);
    options  =  optimset(options , 'TolCon'      , 1e-006);
    options  =  optimset(options , 'Display'     , 'off');
    options  =  optimset(options , 'Diagnostics' , 'off');
    options  =  optimset(options , 'LargeScale'  , 'off');
    options  =  optimset(options , 'MaxIter'     , 1500);
    options  =  optimset(options , 'Jacobian'     ,'off');
    options  =  optimset(options , 'MeritFunction'     ,'multiobj');
    options  =  optimset(options , 'MaxFunEvals' , 3000);
    [est,nlik] = fmincon(model, start_point, AA, BB, [] ,[],lb, ub, [], options);
    loglik = -nlik;
    
     function nln = lik_model(pms)
        beta1 = pms(1:nd);          %coef regime 1
        beta2 = pms((nd+1):2*nd);   %coef regime 2
        if k > nd                   %if some coefficients stay constant across regimes
            beta1 = [beta1; pms(2*nd+1:nd+k)]; %add non-switching coefs
            beta2 = [beta2; pms(2*nd+1:nd+k)]; %add non-switching coefs
        end
        
        sigma2 = pms(nd+k+1);          %variance
        p      = pms(nd+k+2);          %switching prob 1
        q      = pms(nd+k+3);          %switching prob 2
        
        n = length(y);
        nln = 0;
        PRL = zeros(n,1);
        PR = zeros(n,1);
        
        for i=1:n
            if i==1
                PR(i) = (1-q)/(2-p-q);
            else
                PR(i) = p*PRL(i-1)+(1-q)*(1-PRL(i-1));
            end
            PRL(i) = (exp(-(y(i)-x(i,:)*beta1)^2/(2*sigma2))*PR(i))/(exp(-(y(i)-x(i,:)*beta1)^2/(2*sigma2))*PR(i)+exp(-(y(i)-x(i,:)*beta2)^2/(2*sigma2))*(1-PR(i)));
            nln = nln-log(PR(i)*sigma2^(-0.5)*exp((-(y(i)-x(i,:)*beta1)^2)/(2*sigma2))+(1-PR(i))*sigma2^(-0.5)*exp((-(y(i)-x(i,:)*beta2)^2)/(2*sigma2)));
        end
        
    end
end
