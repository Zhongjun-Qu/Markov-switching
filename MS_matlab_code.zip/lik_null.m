%% log likelihood under the null hypothesis; 2pi omitted

function [est, loglik] = lik_null(y,x)

    est  = regress(y,x);
    u  = y-x*est;
    sigma2 = var(u,1);
    loglik = sum(log(sigma2^(-0.5)*exp(-(u.^2)/(2*sigma2))));
    est = [est;sigma2];
    est = est';
        
end