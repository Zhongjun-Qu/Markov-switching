function cv = getcv(y,x,nd,est0,PQ,nrep)

    nrep=max(200,nrep); 
    %at least 200 simulations
    
    count = size(PQ,1);
    
    SLRt=zeros(nrep-1,1);
    %save the simulated values
    
    %generate the covaraince kernel of the Gaussian process
    V = genv(y, x,nd,est0, PQ);
    [A,S,~] = svd(V);
    
    %simulation
    parfor simu=1:(nrep-1)
        u = randn((nd*nd+2)*count,1);
        L234 = (A*sqrt(S)*u);
        [lr,~] = opt(L234,nd,V);
        SLRt(simu) = lr;
                           
    end
    SLRt=sort(SLRt);
    cv=SLRt;
    %get cutoffs
    %cv=[SLRt(ceil(nrep*0.90)),SLRt(ceil(nrep*0.925)),SLRt(ceil(nrep*0.95)),SLRt(ceil(nrep*0.975)),SLRt(ceil(nrep*0.99))];
    
end