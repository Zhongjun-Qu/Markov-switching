%%
%Find the maximum of the objective function that is an
%eighth-order approximation to the log likelihood ratio
%%

function [suplr,tlr] = opt(L234,nd,V)

    Si = size(L234,1)/(nd*nd+2);    %get the number of (p,q) pairs
    tlr = zeros(Si,1);
    
    model = @lr_model;
    options  =  optimset('fminsearch');		
    options  =  optimset(options , 'Display'     , 'off');		
    options  =  optimset(options , 'MaxIter'     , 15000);       
    options  =  optimset(options , 'MaxFunEvals' , 3000);
            
    for cci=1:Si
        for ci=1:8          %8 initial values to ensure convergence
            start_point = unifrnd(-10,10,nd,1);
    		[~,nlr] = fminsearch(model, start_point,options);
            plr = -nlr;
            tlr(cci) = max(tlr(cci),plr); 
        end
           
            
    end
    suplr = max(tlr);
    
    %see the expansion formula in the paper
    function lr = lr_model(xv)
        kxv = kron(xv,xv);
        nd2=nd*nd;
        lr = -L234(((cci-1)*nd2+1):(cci*nd2))'*kxv ...
            +(1/4)*kxv'*V(((cci-1)*nd2+1):(cci*nd2),((cci-1)*nd2+1):(cci*nd2))*kxv ...
            -(1/3)*L234(cci+Si*nd2)*xv(1)^3 ...
            +(1/36)*(V(cci+Si*nd2,cci+Si*nd2)*xv(1)^6) ...
            -(1/12)*L234(cci+Si*nd2+Si)*xv(1)^4 ...
            +(1/576)*(V(cci+Si*nd2+Si,cci+Si*nd2+Si)*xv(1)^8);
    end
    % cci:(p,q); Plus Si: move to the next order in the expansion
end