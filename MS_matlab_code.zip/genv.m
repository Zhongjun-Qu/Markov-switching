%% Covariance kernel for simulating the critical values

%% -----------Input:----------------- %%
% y: a vector of length T
% x: a T-by-k matrix of regressors with the first column equal to 1
% nd: number of regression coefficients allowed to switch;
%     e.g., 1 if only the intercept switches; 2 if the intercept and the
%     first slope coeffcient switch, ...
% est0: parameter estimates under the null hypothesis, regression coefficients followed by
% variance; K+1 vector.
% PQ: a matrix of transition probabilities; each row is a (p,q) pair.
%% ---------------------------------- %%

function V = genv(y,x,nd,est0, PQ)

    T = length(y);                  %time span
    count = size(PQ,1);             %number of (p,q)
    K = size(x,2);                  %number of regressors, including a constant
    
    %% extract estimates under the null hypothesis
    bn   = length(est0);            %K+1
    bHat = est0(1,1:bn-1)';         %exclude the variance
    ess  = est0(bn);                %the variance 
    et   = y-x*bHat;                %residuals under the null hypothesis

    %% calculate the first-order derivatives (f_t)'/(f_t) 
    sg   = 1/sqrt(ess);
    eg   = et*sg;
    d10t = sg*eg;                   %1st order w.r.t the constant term (order (1,0))
    d01t = (sg^2)*(eg.^2-1)/2;      %1st order w.r.t the variance term (order (0,1)).
    
    if K>1
        bd1t = d10t.*x(:,2:K);          %1st order w.r.t the slopes;
                                    %element by element multiplication
        SC = [d10t bd1t d01t];          %full score as a T-by-(K+1) matrix 
    else
        SC = [d10t d01t];          %full score as a T-by-(K+1) matrix 
    end
    
    %% calculate the second-order derivatives (f_t)''/(f_t) and other derivatives
    d20t = (sg^2)*(eg.^2-1);        %2nd order w.r.t the constant term (order (2,0))
    d2tot = zeros(T,nd,nd);         %store the 2nd order derivatives for the parameters allowed to switch
    for j = 1:nd
        for i = 1:nd
            d2tot(:,j,i) = x(:,j).*x(:,i).*d20t;
        end
    end         
    d30t = (sg^3)*(eg.^3-3*eg);     %3rd order w.r.t the constant term (order (3,0))
    d40t = (sg^4)*(eg.^4-6*eg.^2+3);%4th order w.r.t the constant term (order (4,0))
     
    %% calculate the information matrix
     
    IM = SC'*SC/T;
    FM      = IM^-1;                %inverse of information matrix
 
    %% construct the objective function for minimization  
    AY = zeros((nd*nd+2)*count,T);
    for i = 1:count
        p   = PQ(i,1);
        q   = PQ(i,2);
        xi0 = (1-q)/(2-p-q);        % see \xi in the paper
        
        %calculate the first order derivatives of \xi_t with respect to the
        %parameters allowed to switch
        xidt = zeros(T,nd);
        for i1=1:nd
            for i2=2:T
            xidt(i2,i1) = (p+q-1)*xidt(i2-1)+SC(i2-1,i1);
            end
        end
        xidt = xi0*(1-xi0)*(p+q-1)*xidt; %multiply by r
        
        
        %the 2nd order term in the likelihood expansion
        
        A2 = zeros(T,nd*nd);
        for i3 = 1:nd
            for i4 = 1:nd
            A2(:,i3+(i4-1)*nd) = ((1-xi0)/xi0).*d2tot(:,i3,i4) ... 
                +(1/(xi0^2)).*(SC(:,i3).*xidt(:,i4)+SC(:,i4).*xidt(:,i3));
            end
        end
        
        %the variance term for A
        D2 = SC'*A2/T;
        phi2 = -FM*D2;
        J2 = SC*phi2;
        L2 = (A2+J2)';
        
        %the 3rd order term in the likelihood expansion
        A3    = -(1-xi0)*(1-2*xi0)/(xi0^2)*d30t;
        %the variance term for B
        D3 = SC'*A3/T;
        phi3 = -FM*D3; 
        J3 = SC*phi3;
        L3(1,:) = (1/(T^0.25))*(A3+J3)';
        
        % the 4th order terms
        A4 = ((1-xi0)*(1+((1-xi0)/xi0)^3)-3*(1-xi0)^2/(xi0^2))*d40t;
        D4 = SC'*A4/T;
        phi4 = -FM*D4;
        J4 = SC*phi4;
        L4 = (1/(T^0.5))*(A4+J4)';

        
        AY((i-1)*nd*nd+1:i*nd*nd,:)       = L2;
        AY(i+count*nd*nd,:) = L3;
        AY(i+count*(nd*nd+1),:) = L4;
    end
    %AY: 2nd order terms over all (p,q), followed by the 3rd order, and then the
    %4th order
    V = zeros((nd*nd+2)*count,(nd*nd+2)*count); 
    for c1 = 1:(nd*nd+2)*count
        for c2 = 1:(nd*nd+2)*count
           V(c1,c2) = mean(AY(c1,:).*AY(c2,:));
        end
    end

   
end