%% An application of the methods using the GDP series.

    clear; close all; clc

%% load data; replace with your own data
    load GDP;
    D=GDP;              %full sample; as reported in the paper's Table 4
    y = D(:,1);         %colum vector y
    T = size(y,1);
    x = ones(T,2);
    x(:,2) = D(:,2);    %2-by-1: [1,lagged y]
    
%% set up the test and simulation
    trm=0.02;           %the trimming parameter
    nrep=5000;          %the number of simulation replications for critical values
    nd=1;               %the number of regression coefficients allowed to switch
                        %set to 1 for switching in the intercept only
    rng(12345);         %random number generator seed, for replication purposes
    
%% -- The sections below are adaptive; you should not need to modify them -- %%   

%% compute the SupLR test    
    tic
    lp = trm;
    up = 1-trm;
    lq = trm;
    uq = 1-trm; 
    
    %estimation under the null hypothesis
    [est0, loglik0] = lik_null(y,x);
    
    % estimation under the alternative hypothesis using 16 initial values
    % to ensure convergence
    tlr = zeros(16,1);
    estr = zeros(16,size(x,2)+nd+3);
    parfor ct = 1:16
        [est11, loglik1] = lik_alt(y,x,nd,lp,up,lq,uq,trm);  
        tlr(ct) = 2*(loglik1-loglik0);
        estr(ct,:)=est11;
    end
    [mx,ind] = max(tlr); %LR test value
    est1 = estr(ind,:);
   
%% generate critical values   
    indx = 1;
    gtrm = round(100*trm);
    for i=gtrm:2:(100-gtrm)
        for j=i:2:(100-gtrm)
            pi = i/100;
            qi = j/100;
            if (pi+qi)>=(1+eps)
                PQ(indx,1) = pi;
                PQ(indx,2) = qi;
                indx = indx+1;
            end
        end
    end
    slr=getcv(y,x,nd, est0,PQ,nrep); %vector of simulated values; the quantiles are critical values

%% compute the smoothed regime probability
[y, SPR] = smooth(y,x,nd,est1');
    
%% display results
    disp ('Output - see readme for more details:');
    
    disp ('The SupLR test:');
    disp (mx);
    
    disp ('Critical values (10%--7.5%--5%--2.5%--1%):');
    slr=sort(slr);
    cvs=[slr(ceil(nrep*0.90)),slr(ceil(nrep*0.925)),slr(ceil(nrep*0.95)),slr(ceil(nrep*0.975)),slr(ceil(nrep*0.99))];
    disp (cvs);
    
    disp ('P-value:');
    pval=sum(mx<slr)/nrep;
    disp (pval);
    
    disp ('Estimates under the null hypothesis [intercept, slope coefficients, residual variance]:');
    disp (est0);
    
    disp ('Estimates under the alternative hypothesis');
    disp ('[1st regime coefs (intercept followed by slopes), 2nd regime coefs, non-switching slope coefs, residual variance, p,q]:');
    disp (est1);
    SupLR_result=[mx,cvs,pval];
    
    disp ('See the output figure for the smoothed regime probability');
    plot (1-SPR);
    
 %% end of program
 toc
