%% Compute the smoothed regime probability

function [y, SPR] = smooth(y,x,nd,pms)
    %pms: regime 1 regression coefs, regime2 coefs, non-switching regression coefficients (if any), variance, p and q. 
    T = size(y,1);
    k = size (x,2);

    beta1 = pms(1:nd);          %coef regime 1
    beta2 = pms((nd+1):2*nd);   %coef regime 2
    if k > nd                   %if some coefficients stay constant across regimes
        beta1 = [beta1; pms(2*nd+1:nd+k)]; %add non-switching coefs
        beta2 = [beta2; pms(2*nd+1:nd+k)]; %add non-switching coefs
    end
        
    sigma2 = pms(nd+k+1);          %variance
    p      = pms(nd+k+2);          %switching prob 1
    q      = pms(nd+k+3);          %switching prob 2

    nln = 0;
    PRL = zeros(T,1);
    PR = zeros(T,1);

    for i=1:T
        if i==1
            PR(i) = (1-q)/(2-p-q);
        else
            PR(i) = p*PRL(i-1)+(1-q)*(1-PRL(i-1));
        end
        PRL(i) = (exp(-(y(i)-x(i,:)*beta1)^2/(2*sigma2))*PR(i))/(exp(-(y(i)-x(i,:)*beta1)^2/(2*sigma2))*PR(i)+exp(-(y(i)-x(i,:)*beta2)^2/(2*sigma2))*(1-PR(i)));
        nln = nln-log(PR(i)*(2*pi*sigma2)^(-0.5)*exp((-(y(i)-x(i,:)*beta1)^2)/(2*sigma2))+(1-PR(i))*(2*pi*sigma2)^(-0.5)*exp((-(y(i)-x(i,:)*beta2)^2)/(2*sigma2)));

        %PRL(i) = (exp(-(y(i)-beta11*x(i,1)-beta2*x(i,2))^2/(2*sigma2))*PR(i))/(exp(-(y(i)-beta11*x(i,1)-beta2*x(i,2))^2/(2*sigma2))*PR(i)+exp(-(y(i)-beta12*x(i,1)-beta2*x(i,2))^2/(2*sigma2))*(1-PR(i)));
        %nln = nln-log(PR(i)*(2*pi*sigma2)^(-0.5)*exp((-(y(i)-beta11*x(i,1)-beta2*x(i,2))^2)/(2*sigma2))+(1-PR(i))*(2*pi*sigma2)^(-0.5)*exp((-(y(i)-beta12*x(i,1)-beta2*x(i,2))^2)/(2*sigma2)));
    end

SPR = zeros(T,1);
SPR(T,1) = PRL(T,1);
for i=1:T-1
    SPR(T-i) = PRL(T-i)*(p*SPR(T-i+1)/PR(T-i+1)+(1-p)*(1-SPR(T-i+1))/(1-PR(T-i+1)));
end

SPR=SPR.*(SPR<=1)+1.*(SPR>1);

%figure    
%plot(SPR);
end